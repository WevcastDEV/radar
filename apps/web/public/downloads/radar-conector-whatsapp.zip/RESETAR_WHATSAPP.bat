@echo off
title Resetar Conexao WhatsApp
color 0C

echo ===================================================================
echo     RADAR DE OPORTUNIDADES - RESET DE CONEXAO WHATSAPP
echo ===================================================================
echo.
echo  Isso ira apagar os dados de sessao corrompidos.
echo  Voce precisara ler o QR Code novamente apos o reset.
echo.
pause

echo Fechando processos rodando...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 3001 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {} }" >nul 2>&1

echo.
echo Apagando a pasta auth_info_baileys...
if exist "%~dp0auth_info_baileys" (
    rmdir /s /q "%~dp0auth_info_baileys"
    echo [OK] Pasta apagada!
) else (
    echo [OK] Pasta ja estava vazia.
)

echo.
echo O WhatsApp foi resetado com sucesso!
echo.
echo Agora execute o INICIAR_CONECTOR.bat novamente para gerar um novo QR Code.
echo.
pause
